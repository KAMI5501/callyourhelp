
      document.onkeydown = function(a) {
        return !1
      };
   
   